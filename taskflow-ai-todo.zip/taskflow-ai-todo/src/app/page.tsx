import TaskFlowApp from '@/components/TaskFlowApp';

export default function Home() {
  return <TaskFlowApp />;
}
