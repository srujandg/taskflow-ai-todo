import { config } from 'dotenv';
config();

import '@/ai/flows/prioritize-tasks.ts';